.. cmake-module:: ../../Modules/CPack.cmake
