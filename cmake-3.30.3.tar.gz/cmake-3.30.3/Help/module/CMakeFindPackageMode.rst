.. cmake-module:: ../../Modules/CMakeFindPackageMode.cmake
