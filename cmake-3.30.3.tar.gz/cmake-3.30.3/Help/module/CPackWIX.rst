CPackWIX
--------

The documentation for the CPack WIX generator has moved here:
:cpack_gen:`CPack WIX Generator`
