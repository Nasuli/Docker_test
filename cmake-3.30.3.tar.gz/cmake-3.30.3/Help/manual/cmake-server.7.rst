.. cmake-manual-description: CMake Server

cmake-server(7)
***************

The :manual:`cmake(1)` server mode has been removed since CMake 3.20.
Clients should use the :manual:`cmake-file-api(7)` instead.
